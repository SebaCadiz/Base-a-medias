from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate
from .models import Usuario, ClasificacionTributaria, Contribuyente, Pais
from django.contrib.auth.hashers import make_password
import re
from django.contrib import messages
from .pulsar import publicar_evento
from .models import Evento
from django.http import JsonResponse
from .services.exchange import convert_currency, list_currencies


def login_view(request):
    if 'usuario_id' in request.session:
        return redirect('index')

    if request.method == 'POST':
        usuario_correo = request.POST.get('username').lower()
        contrasena = request.POST.get('password')    

        user = authenticate(request, username=usuario_correo, password=contrasena)

        if user is not None:
            request.session['usuario_id'] = user.pk 
            request.session['usuario_nombre'] = user.nombre
            
            messages.success(request, f"Bienvenido, {user.nombre}")
            return redirect('index')
        else:
            messages.error(request, "Credenciales inválidas (Correo o contraseña incorrectos)")
            return redirect('crear_usuario') 
    
    return redirect('crear_usuario')

# --- VISTA 2: Logout (Cerrar Sesión Manual) ---
def logout_view(request):
    request.session.flush() 
    
    messages.info(request, "Has cerrado sesión correctamente.")
    return redirect('crear_usuario')


def index(request):
    # 1. Verificación de seguridad: ¿Existe la sesión?
    if 'usuario_id' not in request.session:
        messages.warning(request, "Debes iniciar sesión para ver esta página.")
        return redirect('crear_usuario') # Te manda al login si no hay sesión

    # 2. Recuperar datos del usuario
    usuario_id = request.session['usuario_id']
    
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        # Si el usuario fue borrado de la DB pero la cookie seguía viva
        request.session.flush()
        return redirect('crear_usuario')

    context = {
        'usuario': usuario
    }
    return render(request, 'index.html', context)


def crear_usuario(request):
    if 'usuario_id' in request.session:
        return redirect('index')

    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        mail = request.POST.get('mail').lower()
        contrasena = request.POST.get('contraseña')
        rol = request.POST.get('rol')
        
        patron_correo = r'^[a-zA-Z0-9._%+-]+@gmail.com$'

        # Validaciones
        if not mail or not nombre or not contrasena:
             messages.error(request, "Por favor completa todos los campos.")
             return redirect('crear_usuario')
        elif not re.match(patron_correo, mail):
            messages.error(request, "El formato del correo no es válido. Debe ser tipo ejemplo@gmail.com")
            return redirect('crear_usuario')
        elif len(contrasena) < 6:
            messages.error(request, "La contraseña debe tener al menos 6 caracteres.")
            return redirect('crear_usuario')
        elif Usuario.objects.filter(mail=mail).exists():
            messages.error(request, "Ya existe una cuenta con ese correo.")
            return redirect('crear_usuario')
        elif rol not in ['cliente', 'administrador']:
            messages.error(request, "El rol seleccionado no es válido.")
            return redirect('crear_usuario')

 
        # Guardar nuevo usuario
        nuevo_usuario = Usuario(
            nombre=nombre,
            apellido=apellido,
            mail=mail,
            contraseña=make_password(contrasena), 
            rol=rol
        )
        nuevo_usuario.save()
        publicar_evento('USUARIO_CREADO', {
            'usuario_id': nuevo_usuario.id_usuario,
            'nombre': nuevo_usuario.nombre,
            'mail': nuevo_usuario.mail,
            'rol': nuevo_usuario.rol
        })

        messages.success(request, "Cuenta creada exitosamente. ¡Ahora inicia sesión!")
        return redirect('crear_usuario')

    # GET: Mostrar el HTML
    return render(request, 'crear_usuario.html')


def manejo(request):
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')

    usuario_id = request.session['usuario_id']

    try:
        usuario_logueado = Usuario.objects.get(pk=usuario_id)
        if usuario_logueado.rol != 'administrador':
            return redirect('index')
        todos_los_usuarios = Usuario.objects.all() 
        context = {
            'usuario': usuario_logueado,
            'usuarios': todos_los_usuarios 
        }
        return render(request, 'manejo_usuario.html', context)
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')


def editar_usuario(request, user_id):
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    usuario_id = request.session['usuario_id']
    try:
        usuario_logueado = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')
    if usuario_logueado.rol != 'administrador':
        return redirect('index')
    try:
        usuario_obj = Usuario.objects.get(pk=user_id)
    except Usuario.DoesNotExist:
        messages.error(request, 'Usuario no encontrado.')
        return redirect('manejo')
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        mail = request.POST.get('mail').lower() if request.POST.get('mail') else ''
        rol = request.POST.get('rol')
        patron_correo = r'^[a-zA-Z0-9._%+-]+@gmail.com$'
        
        
        if not nombre or not mail:
            messages.error(request, 'Nombre y mail son obligatorios.')
            return redirect('editar', user_id=user_id)
        elif Usuario.objects.filter(mail=mail).exclude(pk=usuario_obj.pk).exists():
            messages.error(request, 'El correo ya está en uso por otro usuario.')
            return redirect('editar', user_id=user_id)
        elif not re.match(patron_correo, mail):
            messages.error(request, 'El formato del correo no es válido. Debe ser tipo')
            return redirect('editar', user_id=user_id)
        
        usuario_obj.nombre = nombre
        usuario_obj.apellido = apellido
        usuario_obj.mail = mail
        if rol in ['cliente', 'administrador']:
            usuario_obj.rol = rol

        usuario_obj.save()
        messages.success(request, 'Usuario actualizado correctamente.')
        return redirect('manejo')

    # GET -> mostrar formulario
    context = {
        'usuario': usuario_logueado,
        'target': usuario_obj,
        'mode': 'editar'
    }
    return render(request, 'edicion_eliminacion.html', context)


def eliminar_usuario(request, user_id):
    # Requiere sesión y rol administrador
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')

    usuario_id = request.session['usuario_id']
    try:
        usuario_logueado = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')

    if usuario_logueado.rol != 'administrador':
        return redirect('index')

    try:
        usuario_obj = Usuario.objects.get(pk=user_id)
    except Usuario.DoesNotExist:
        messages.error(request, 'Usuario no encontrado.')
        return redirect('manejo')
    if request.method == 'POST':
        # Confirm deletion
        usuario_obj.delete()
        messages.success(request, 'Usuario eliminado correctamente.')
        return redirect('manejo')

    # GET -> mostrar confirmación
    context = {
        'usuario': usuario_logueado,
        'target': usuario_obj,
        'mode': 'eliminar'
    }
    return render(request, 'edicion_eliminacion.html', context)

TIPO_CONTRIBUYENTE_CHOICES = {
    'Jurídica': 'Jurídica',
    'Natural': 'Natural'
}
def manejo_tributarios(request):
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    
    usuario_id = request.session['usuario_id']
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
        contribuyentes = Contribuyente.objects.filter(id_usuario=usuario)
        paises = Pais.objects.all()
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')
    
    context = {
        'usuario': usuario,
        'contribuyentes': contribuyentes,
        'paises': paises,
        'tipos_contribuyente': TIPO_CONTRIBUYENTE_CHOICES.items(),
        'situacion_choices': ['Activo', 'Inactivo'] 
    }
    return render(request, 'manejo_tributarios.html', context)

def crear_contribuyente(request):
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    
    usuario_id = request.session['usuario_id']
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')
    
    if request.method == 'POST':
        try:
            # 1. Captura de datos del formulario (ahora incluyendo 'tipo' y 'empleados')
            id_pais = request.POST.get('id_pais')
            tipo = request.POST.get('tipo') # Nuevo campo
            situacion = request.POST.get('situacion')
            nombre_comercial = request.POST.get('nombre_comercial')
            actividad_economica = request.POST.get('actividad_economica')
            identificador_tributario = request.POST.get('identificador_tributario')
            empleados_str = request.POST.get('empleados') # Capturamos como string
            empleados = int(empleados_str) if empleados_str.isdigit() else 0

            # 2. Obtener objeto FK
            pais = Pais.objects.get(pk=id_pais)
            
            # 3. Creación y guardado
            contribuyente = Contribuyente(
                id_usuario=usuario,
                id_pais=pais,
                tipo=tipo, # Guardamos el tipo directamente
                situación=situacion,
                nombre_comercial=nombre_comercial,
                actividad_economica=actividad_economica,
                identificador_tributario=identificador_tributario,
                empleados=empleados # Guardamos el número de empleados
            )
            contribuyente.save()
            messages.success(request, f'Contribuyente "{nombre_comercial}" creado exitosamente.')
            
            return redirect('manejo_tributarios')
        
        except Pais.DoesNotExist:
            messages.error(request, 'País seleccionado inválido.')
        except Exception as e:
            messages.error(request, f'Error al crear contribuyente: {str(e)}')
            
        return redirect('manejo_tributarios')
    
    return redirect('manejo_tributarios')


def editar_tributario(request, contribuyente_id): # <--- Argumento ajustado
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    
    usuario_id = request.session['usuario_id']
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
        # Usamos contribuyente_id en la consulta
        contribuyente = Contribuyente.objects.get(pk=contribuyente_id, id_usuario=usuario) 
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')
    except Contribuyente.DoesNotExist:
        messages.error(request, 'Contribuyente no encontrado o no autorizado.')
        return redirect('manejo_tributarios')
    
    if request.method == 'POST':
        try:
            # Capturar y actualizar TODOS los campos
            tipo = request.POST.get('tipo')
            situacion = request.POST.get('situacion')
            nombre_comercial = request.POST.get('nombre_comercial')
            actividad_economica = request.POST.get('actividad_economica')
            identificador_tributario = request.POST.get('identificador_tributario')
            
            # Manejo del campo 'empleados'
            empleados_str = request.POST.get('empleados')
            # Si el tipo es Natural, forzamos 0 si el campo está vacío, sino convertimos a int
            if tipo == 'Natural' or not empleados_str:
                empleados = 0
            else:
                empleados = int(empleados_str)
            
            # Asignación de valores al objeto
            contribuyente.tipo = tipo
            contribuyente.situación = situacion
            contribuyente.nombre_comercial = nombre_comercial
            contribuyente.actividad_economica = actividad_economica
            contribuyente.identificador_tributario = identificador_tributario
            contribuyente.empleados = empleados
            
            contribuyente.save()
            messages.success(request, 'Contribuyente actualizado correctamente.')
            return redirect('manejo_tributarios')
        except ValueError:
            messages.error(request, 'El número de empleados debe ser un valor entero.')
        except Exception as e:
            messages.error(request, f'Error al actualizar: {str(e)}')
            
    context = {
        'usuario': usuario,
        'contribuyente': contribuyente,
        'tipos_contribuyente': TIPO_CONTRIBUYENTE_CHOICES.items(),
        'situacion_choices': ['Activo', 'Inactivo'],
        'mode': 'editar'
    }
    return render(request, 'editar_tributario.html', context)


def eliminar_tributario(request, contribuyente_id): # <--- Argumento ajustado
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    
    usuario_id = request.session['usuario_id']
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
        # Usamos contribuyente_id en la consulta
        contribuyente = Contribuyente.objects.get(pk=contribuyente_id, id_usuario=usuario) 
    except (Usuario.DoesNotExist, Contribuyente.DoesNotExist):
        messages.error(request, 'Contribuyente no encontrado o no autorizado.')
        return redirect('manejo_tributarios')
    
    if request.method == 'POST':
        contribuyente.delete()
        messages.success(request, 'Contribuyente eliminado exitosamente.')
        return redirect('manejo_tributarios')
        
    context = {
        'usuario': usuario,
        'contribuyente': contribuyente,
        'tipos_contribuyente': TIPO_CONTRIBUYENTE_CHOICES.items(), 
        'mode': 'eliminar'
    }
    return render(request, 'editar_tributario.html', context)

def clasificaciones_por_contribuyente(request, contribuyente_id):
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')

    usuario_id = request.session['usuario_id']

    # 1. DEFINIR USUARIO FUERA DEL TRY PRINCIPAL
    try:
        usuario = Usuario.objects.get(pk=usuario_id) 
    except Usuario.DoesNotExist:
        # Esto maneja si la sesión está activa pero el usuario fue eliminado
        request.session.flush()
        return redirect('crear_usuario')
        
    # 2. SEGUNDO TRY: Búsqueda de Contribuyente y Clasificaciones
    try:
        # Usamos el 'usuario' ya definido
        contribuyente = Contribuyente.objects.get(pk=contribuyente_id, id_usuario=usuario) 
        clasificaciones = ClasificacionTributaria.objects.filter(id_contribuyente=contribuyente)
        
    except Contribuyente.DoesNotExist:
        messages.error(request, "Contribuyente no encontrado o no pertenece al usuario.")
        return redirect('manejo_tributarios')
    
    except Exception as e:
        # Manejo de cualquier otro error de base de datos o inesperado
        messages.error(request, f"Error al cargar clasificaciones: {e}")
        return redirect('manejo_tributarios')

    context = {
        'usuario': usuario,
        'contribuyente': contribuyente,
        'clasificaciones': clasificaciones
    }
    return render(request, 'clasificaciones_por_contribuyente.html', context)


def clasificacion(request):
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')

    usuario_id = request.session['usuario_id']

    try:
        usuario = Usuario.objects.get(pk=usuario_id)
        contribuyentes_del_usuario = Contribuyente.objects.filter(id_usuario=usuario)
        clasificaciones = ClasificacionTributaria.objects.filter(id_contribuyente__in=contribuyentes_del_usuario) 
        
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')

    context = {
        'usuario': usuario,
        'clasificaciones': clasificaciones
    }
    # NOTA: Este es el listado general (no por contribuyente)
    return render(request, 'clasificaciones_tributarias.html', context)

def lista_eventos(request):
    eventos = Evento.objects.order_by("-timestamp")
    return render(request, "eventos.html", {"eventos": eventos})

def divisas_page(request):
    """Página para el conversor de divisas. Requiere sesión."""
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    usuario_id = request.session['usuario_id']
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')
    context = {'usuario': usuario}
    return render(request, 'divisas.html', context)
def faq_page(request):
    """Página de Preguntas Frecuentes. Requiere sesión."""
    if 'usuario_id' not in request.session:
        return redirect('crear_usuario')
    usuario_id = request.session['usuario_id']
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
    except Usuario.DoesNotExist:
        request.session.flush()
        return redirect('crear_usuario')
    context = {'usuario': usuario}
    return render(request, 'faq.html', context)
def api_convert(request):
    """Endpoint: /api/convert/?from_currency=USD&to_currency=EUR&amount=10"""
    from_cur = request.GET.get('from_currency') or request.GET.get('from')
    to_cur = request.GET.get('to_currency') or request.GET.get('to')
    amount = request.GET.get('amount', 1)

    try:
        result = convert_currency(from_cur, to_cur, amount)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

    status = 400 if "error" in result else 200
    return JsonResponse(result, status=status, safe=False)


def api_currencies(request):
    base = request.GET.get('base', 'USD')
    try:
        result = list_currencies(base)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
    status = 400 if "error" in result else 200
    return JsonResponse(result, status=status, safe=False)